ORIGINAL VICTORIAN TRIPLES CSV EXPORTS

Period requested: 2026-07-01 through 2026-11-25.
Package status: complete_enumeration.
Original CSV files included: 817.
Race records inspected: 1608.
Calendar meetings enumerated: 205.

Every file under original_csv/ is the exact downloaded byte sequence. Filenames
use Racing.com's meeting ID and two-digit race number. The date folder comes
from Racing.com's calendar. No columns, headers, values, delimiters or dates
have been changed. SHA256SUMS.txt verifies the originals.

The files are labelled TripleS by Racing.com's website data. This identifies
the provider; it does not guarantee that this export has exactly the same
fields or layout as another TripleS feed.

Formats vary. Some dates use day/month, others month/day, and newer files use
ISO dates. The meeting label also contains an ISO date. Metadata rows can have
three or five fields. Horse rows contain repeating distance, speed and split
duration fields. Some opening sections are shorter than 200m. Some scratched
or untracked runners are zero-filled. Interpret those using the existing
provider parser; they have not been removed.

coverage.csv lists every recorded race, including Daily Sectionals and absent
data. A displayed download link or HTTP 200 response alone is not evidence of
a CSV: some links return a no-content HTML page. Those HTML responses are not
included as CSVs. No replacement CSVs were generated.

flagged_originals.csv lists originals with inspection concerns; they are still
included unchanged for review. This package is an acquisition handoff, not a
claim that every row is suitable for direct database insertion.

Only original race CSV exports are bundled. The full historical PDF archive
was not downloaded in this backfill. The CSV exports do not themselves carry
all stride or distance-from-rail fields shown in some companion PDFs.

No database, ratings, production pipeline or scheduled job was changed.
The user's supplied template was not used to rewrite these source files.
